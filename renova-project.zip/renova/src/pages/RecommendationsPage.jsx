import { useState } from "react";
import Navbar from "../components/Navbar";
import BackBtn from "../components/BackBtn";
import { CircProg } from "../components/Charts";
import { mockRecommendations } from "../data/mockData";

export default function RecommendationsPage({ navigate, logout, goBack }) {
  const [tab, setTab] = useState("direct");
  const [expanded, setExpanded] = useState(null);
  const [saved, setSaved] = useState([]);
  const tabs = [["direct", "Direct Comeback"], ["adjacent", "Adjacent Roles"], ["replacement", "New Horizons"]];
  const roles = mockRecommendations[tab] || [];

  return (
    <div>
      <Navbar navigate={navigate} logout={logout} activePage="recommendations" goBack={goBack} canGoBack={true} />
      <div style={{ padding: "36px 5%", maxWidth: 920, margin: "0 auto" }}>
        <BackBtn goBack={goBack} canGoBack={true} style={{ marginBottom: 24 }} />
        <div className="fu1" style={{ marginBottom: 32 }}>
          <div style={{ width: 32, height: 1, background: "#c2185b", marginBottom: 16 }} />
          <h1 className="serif" style={{ fontSize: 40, color: "#1a0a12", fontWeight: 300, marginBottom: 6 }}>Your matched <em style={{ color: "#c2185b" }}>opportunities</em></h1>
          <p style={{ color: "#5a3048", fontSize: 15, fontWeight: 300 }}>AI-curated roles based on your experience, skills, and goals.</p>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", borderBottom: "1px solid rgba(194,24,91,0.1)", marginBottom: 32 }} className="fu2">
          {tabs.map(([k, l]) => (
            <div key={k} onClick={() => setTab(k)} style={{ padding: "13px 24px", cursor: "pointer", fontSize: 14, fontWeight: tab === k ? 600 : 400, color: tab === k ? "#c2185b" : "#6b3550", borderBottom: tab === k ? "2px solid #c2185b" : "2px solid transparent", marginBottom: -1, transition: "all 0.2s" }}>{l}</div>
          ))}
        </div>

        {/* Role Cards */}
        {roles.map((role, i) => (
          <div key={role.id} className="role-row" style={{ animationDelay: `${i * 0.08}s` }}>
            <div style={{ padding: "24px 0", display: "flex", alignItems: "center", gap: 20 }} onClick={() => setExpanded(expanded === role.id ? null : role.id)}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6, flexWrap: "wrap" }}>
                  <h3 style={{ fontSize: 17, fontWeight: 600, color: "#1a0a12" }}>{role.title}</h3>
                  <span style={{ fontSize: 12, color: "#9d6b82" }}>at {role.company}</span>
                  <span style={{ fontSize: 11, fontWeight: 700, color: "#c2185b", background: "rgba(194,24,91,0.07)", padding: "3px 10px", letterSpacing: "0.05em" }}>{role.match}% MATCH</span>
                </div>
                <div style={{ display: "flex", gap: 16, fontSize: 13, color: "#5a3048", fontWeight: 300 }}>
                  <span>{role.salary}</span>
                  <span style={{ color: "rgba(194,24,91,0.3)" }}>|</span>
                  <span>{role.type}</span>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ position: "relative", width: 46, height: 46 }}>
                  <CircProg value={role.match} size={46} sw={4} />
                  <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: "#c2185b" }}>{role.match}</div>
                </div>
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" style={{ transform: expanded === role.id ? "rotate(180deg)" : "rotate(0)", transition: "transform 0.3s", color: "#9d6b82" }}>
                  <path d="M3 5L7 9L11 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
              </div>
            </div>
            {expanded === role.id && (
              <div style={{ paddingBottom: 24 }}>
                <p style={{ fontSize: 14, color: "#5a3048", lineHeight: 1.85, marginBottom: 18, fontWeight: 300 }}>{role.desc}</p>
                <p style={{ fontSize: 11, fontWeight: 700, color: "#9d6b82", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10 }}>Skills gaps to close</p>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 }}>
                  {role.gap.map(g => <span key={g} className="tag-chip" style={{ background: "rgba(245,158,11,0.07)", color: "#b45309", borderColor: "rgba(245,158,11,0.18)" }}>{g}</span>)}
                </div>
                <div style={{ display: "flex", gap: 12 }}>
                  <button className="btn-primary" style={{ borderRadius: 3, padding: "10px 22px", fontSize: 13 }} onClick={() => setSaved(s => s.includes(role.id) ? s.filter(x => x !== role.id) : [...s, role.id])}>
                    {saved.includes(role.id) ? "Saved" : "Save to List"}
                  </button>
                  <button className="btn-outline" style={{ borderRadius: 3, padding: "9px 18px", fontSize: 13 }}>Close Skill Gaps</button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
