import { useState } from "react";
import { AuthWrap, Field, PwStrength } from "../components/AuthComponents";

export function LoginPage({ navigate, onLogin, goBack, canGoBack }) {
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  return (
    <AuthWrap
      title="Welcome back."
      sub="Continue your career comeback."
      navigate={navigate}
      goBack={goBack}
      canGoBack={canGoBack}
      altText="No account?"
      altAction="signup"
      altLabel="Join Renova"
    >
      <Field label="Email" type="email" value={email} onChange={setEmail} placeholder="you@email.com" />
      <Field label="Password" type="password" value={pw} onChange={setPw} placeholder="Your password" />
      <button className="btn-primary" style={{ width: "100%", borderRadius: 3, marginTop: 6 }} onClick={() => email && pw && onLogin({ name: email.split("@")[0], email })}>
        Sign In
      </button>
    </AuthWrap>
  );
}

export function SignupPage({ navigate, onSignup, goBack, canGoBack }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  return (
    <AuthWrap
      title="Begin your comeback."
      sub="Free forever. No credit card."
      navigate={navigate}
      goBack={goBack}
      canGoBack={canGoBack}
      altText="Already have an account?"
      altAction="login"
      altLabel="Sign in"
    >
      <Field label="Your Name" value={name} onChange={setName} placeholder="First name" />
      <Field label="Email" type="email" value={email} onChange={setEmail} placeholder="you@email.com" />
      <Field label="Password" type="password" value={pw} onChange={setPw} placeholder="Minimum 8 characters" />
      <PwStrength pw={pw} />
      <button className="btn-primary" style={{ width: "100%", borderRadius: 3 }} onClick={() => name && email && pw && onSignup({ name, email })}>
        Create My Account
      </button>
      <p style={{ fontSize: 12, color: "#9d6b82", marginTop: 16, lineHeight: 1.6 }}>By joining, you agree to our Terms and Privacy Policy.</p>
    </AuthWrap>
  );
}
