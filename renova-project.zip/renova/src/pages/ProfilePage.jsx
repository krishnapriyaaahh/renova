import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";
import BackBtn from "../components/BackBtn";
import { MiniLine } from "../components/Charts";
import { dashboardMetrics, defaultProfile } from "../data/mockData";

const banners = [
  "linear-gradient(135deg, #fce8f3, #e91e8c 60%, #c2185b)",
  "linear-gradient(135deg, #1a0a12, #4a1030 50%, #c2185b)",
  "linear-gradient(135deg, #fce8f3, #f9a8d4 40%, #fce8f3)",
  "linear-gradient(160deg, #c2185b, #e91e8c 40%, #f9a8d4)",
];

function Chip({ children, onRemove, editing }) {
  return (
    <span className="tag-chip">
      {children}
      {onRemove && editing && <span style={{ cursor: "pointer", opacity: 0.45, marginLeft: 2 }} onClick={onRemove}>&times;</span>}
    </span>
  );
}

function Sec({ label, children }) {
  return (
    <div className="profile-section">
      <div className="sec-label">{label}</div>
      {children}
    </div>
  );
}

export default function ProfilePage({ navigate, logout, goBack }) {
  const { user } = useAuth();
  const [editing, setEditing] = useState(false);
  const [bannerIdx, setBannerIdx] = useState(0);
  const [p, setP] = useState({ ...defaultProfile, name: user?.name || "Alexandra Chen" });

  const up = (k, v) => setP(pp => ({ ...pp, [k]: v }));
  const upArr = (k, id, f, v) => setP(pp => ({ ...pp, [k]: pp[k].map(x => x.id === id ? { ...x, [f]: v } : x) }));
  const addArr = (k, item) => setP(pp => ({ ...pp, [k]: [...pp[k], item] }));
  const rmArr = (k, id) => setP(pp => ({ ...pp, [k]: pp[k].filter(x => x.id !== id) }));

  return (
    <div>
      <Navbar navigate={navigate} logout={logout} activePage="profile" goBack={goBack} canGoBack={true} />
      <div style={{ maxWidth: 820, margin: "0 auto", paddingBottom: 60 }}>
        <BackBtn goBack={goBack} canGoBack={true} style={{ margin: "20px 40px 0", display: "inline-flex" }} />

        {/* Banner */}
        <div style={{ height: 172, background: banners[bannerIdx], position: "relative", marginTop: 12 }}>
          {editing && (
            <div style={{ position: "absolute", bottom: 12, right: 16, display: "flex", gap: 8 }}>
              {banners.map((_, i) => (
                <div key={i} onClick={() => setBannerIdx(i)} style={{ width: 20, height: 20, background: banners[i], border: `2px solid ${bannerIdx === i ? "white" : "transparent"}`, cursor: "pointer" }} />
              ))}
            </div>
          )}
        </div>

        {/* Avatar & Edit Button */}
        <div style={{ padding: "0 40px", position: "relative" }}>
          <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginTop: -42 }}>
            <div style={{ width: 84, height: 84, background: "linear-gradient(135deg,#e91e8c,#c2185b)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, fontWeight: 300, color: "white", border: "4px solid white", boxShadow: "0 4px 20px rgba(194,24,91,0.2)", fontFamily: "'Cormorant Garamond',serif" }}>
              {p.name?.[0]?.toUpperCase()}
            </div>
            <button className={editing ? "btn-primary" : "btn-outline"} style={{ borderRadius: 3, fontSize: 13, padding: "9px 20px" }} onClick={() => setEditing(!editing)}>
              {editing ? "Save Profile" : "Edit Profile"}
            </button>
          </div>

          {/* Name & Headline */}
          <div style={{ marginTop: 16, marginBottom: 14 }}>
            {editing
              ? <input value={p.name} onChange={e => up("name", e.target.value)} className="input-field" style={{ fontSize: 26, fontFamily: "'Cormorant Garamond',serif", fontWeight: 600, marginBottom: 10, display: "block" }} />
              : <h1 className="serif" style={{ fontSize: 30, color: "#1a0a12", fontWeight: 600, marginBottom: 6 }}>{p.name}</h1>
            }
            {editing
              ? <input value={p.headline} onChange={e => up("headline", e.target.value)} className="input-field" style={{ fontSize: 14, marginBottom: 10, display: "block" }} />
              : <p style={{ fontSize: 14, color: "#2d1a25", lineHeight: 1.65, marginBottom: 10 }}>{p.headline}</p>
            }
            <div style={{ display: "flex", gap: 20, fontSize: 13, color: "#7a3d58", flexWrap: "wrap" }}>
              {editing
                ? <>
                  <input value={p.location} onChange={e => up("location", e.target.value)} className="input-field" style={{ fontSize: 13, width: 200 }} placeholder="Location" />
                  <input value={p.website} onChange={e => up("website", e.target.value)} className="input-field" style={{ fontSize: 13, width: 220 }} placeholder="LinkedIn / Website URL" />
                </>
                : <><span>{p.location}</span>{p.website && <span style={{ color: "#c2185b" }}>{p.website}</span>}</>
              }
            </div>
          </div>

          {/* Open To Banner */}
          <div style={{ padding: "12px 16px", background: "rgba(194,24,91,0.04)", borderLeft: "2px solid #c2185b", marginBottom: 16 }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: "#c2185b", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 8 }}>Open To</p>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {p.openTo.map(o => <Chip key={o} editing={editing} onRemove={() => up("openTo", p.openTo.filter(x => x !== o))}>{o}</Chip>)}
              {p.targetRoles.map(r => <Chip key={r} editing={editing}>{r}</Chip>)}
            </div>
          </div>

          {/* Resume Upload */}
          <div style={{ padding: "18px 20px", border: "1.5px dashed rgba(194,24,91,0.18)", textAlign: "center", cursor: "pointer", marginBottom: 8, transition: "all 0.2s" }} onMouseEnter={e => e.currentTarget.style.background = "rgba(194,24,91,0.02)"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            <p style={{ fontWeight: 600, color: "#c2185b", fontSize: 13, marginBottom: 2 }}>Upload CV / Resume</p>
            <p style={{ fontSize: 12, color: "#9d6b82" }}>PDF or DOCX · Used to auto-tailor your applications</p>
          </div>

          {/* About */}
          <Sec label="About">
            {editing
              ? <textarea value={p.about} onChange={e => up("about", e.target.value)} className="input-field" style={{ width: "100%", minHeight: 110, resize: "vertical", lineHeight: 1.75, fontSize: 14 }} />
              : <p style={{ fontSize: 15, color: "#2d1a25", lineHeight: 1.9, fontWeight: 300, whiteSpace: "pre-line" }}>{p.about}</p>
            }
          </Sec>

          {/* Career Break */}
          <Sec label="Career Break">
            <div style={{ padding: "16px 18px", background: "rgba(194,24,91,0.03)", border: "1px solid rgba(194,24,91,0.1)" }}>
              <p style={{ fontSize: 11, fontWeight: 700, color: "#c2185b", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 8 }}>Intentional Career Pause · 2021 – 2024</p>
              {editing
                ? <textarea value={p.careerBreak} onChange={e => up("careerBreak", e.target.value)} className="input-field" style={{ width: "100%", minHeight: 88, resize: "vertical", lineHeight: 1.75, fontSize: 13 }} />
                : <p style={{ fontSize: 14, color: "#2d1a25", lineHeight: 1.85, fontWeight: 300 }}>{p.careerBreak}</p>
              }
            </div>
          </Sec>

          {/* Experience */}
          <Sec label="Experience">
            {p.experience.map((e, i) => (
              <div key={e.id} style={{ marginBottom: 26, paddingBottom: 26, borderBottom: i < p.experience.length - 1 ? "1px solid rgba(180,100,130,0.1)" : "none" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, marginBottom: 8 }}>
                  <div style={{ flex: 1 }}>
                    {editing
                      ? <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                        <input value={e.title} onChange={ev => upArr("experience", e.id, "title", ev.target.value)} className="input-field" style={{ fontSize: 15, fontWeight: 600 }} placeholder="Job title" />
                        <div style={{ display: "flex", gap: 8 }}>
                          <input value={e.company} onChange={ev => upArr("experience", e.id, "company", ev.target.value)} className="input-field" style={{ fontSize: 14 }} placeholder="Company" />
                          <input value={e.location} onChange={ev => upArr("experience", e.id, "location", ev.target.value)} className="input-field" style={{ fontSize: 14 }} placeholder="Location" />
                        </div>
                      </div>
                      : <><h3 style={{ fontSize: 16, fontWeight: 600, color: "#1a0a12" }}>{e.title}</h3>
                        <p style={{ fontSize: 14, color: "#5a3048", marginTop: 3 }}>{e.company} · {e.location}</p></>
                    }
                  </div>
                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    <p style={{ fontSize: 12, color: "#9d6b82", fontWeight: 500, whiteSpace: "nowrap" }}>{e.start} – {e.current ? "Present" : e.end}</p>
                    {editing && <button style={{ fontSize: 11, color: "#c2185b", background: "none", border: "none", cursor: "pointer", marginTop: 6 }} onClick={() => rmArr("experience", e.id)}>Remove</button>}
                  </div>
                </div>
                {editing
                  ? <textarea value={e.desc} onChange={ev => upArr("experience", e.id, "desc", ev.target.value)} className="input-field" style={{ width: "100%", minHeight: 80, resize: "vertical", fontSize: 13, lineHeight: 1.75 }} />
                  : <p style={{ fontSize: 14, color: "#5a3048", lineHeight: 1.85, fontWeight: 300, marginTop: 8 }}>{e.desc}</p>
                }
              </div>
            ))}
            {editing && <button className="btn-outline" style={{ borderRadius: 3, fontSize: 13, padding: "9px 20px" }} onClick={() => addArr("experience", { id: Date.now(), title: "", company: "", location: "", start: "", end: "", current: false, desc: "" })}>+ Add Position</button>}
          </Sec>

          {/* Education */}
          <Sec label="Education">
            {p.education.map((e, i) => (
              <div key={e.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18, paddingBottom: 18, borderBottom: i < p.education.length - 1 ? "1px solid rgba(180,100,130,0.1)" : "none" }}>
                <div style={{ flex: 1 }}>
                  {editing
                    ? <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                      <input value={e.institution} onChange={ev => upArr("education", e.id, "institution", ev.target.value)} className="input-field" style={{ fontSize: 15, fontWeight: 600 }} placeholder="Institution" />
                      <input value={e.degree} onChange={ev => upArr("education", e.id, "degree", ev.target.value)} className="input-field" style={{ fontSize: 14 }} placeholder="Degree" />
                    </div>
                    : <><h3 style={{ fontSize: 15, fontWeight: 600, color: "#1a0a12" }}>{e.institution}</h3>
                      <p style={{ fontSize: 13, color: "#5a3048", marginTop: 3, fontWeight: 300 }}>{e.degree}</p></>
                  }
                </div>
                <div style={{ textAlign: "right", flexShrink: 0, marginLeft: 20 }}>
                  <p style={{ fontSize: 12, color: "#9d6b82" }}>{e.years}</p>
                  <p style={{ fontSize: 12, color: "#c2185b", fontWeight: 600, marginTop: 4 }}>{e.grade}</p>
                  {editing && <button style={{ fontSize: 11, color: "#c2185b", background: "none", border: "none", cursor: "pointer", marginTop: 6 }} onClick={() => rmArr("education", e.id)}>Remove</button>}
                </div>
              </div>
            ))}
            {editing && <button className="btn-outline" style={{ borderRadius: 3, fontSize: 13, padding: "9px 20px" }} onClick={() => addArr("education", { id: Date.now(), institution: "", degree: "", years: "", grade: "" })}>+ Add Education</button>}
          </Sec>

          {/* Certifications */}
          <Sec label="Certifications">
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {p.certifications.map(c => (
                <div key={c.id} style={{ padding: "14px 16px", background: "rgba(255,255,255,0.55)", border: "1px solid rgba(194,24,91,0.1)" }}>
                  <p style={{ fontWeight: 600, fontSize: 14, color: "#1a0a12", marginBottom: 3 }}>{c.name}</p>
                  <p style={{ fontSize: 12, color: "#7a3d58" }}>{c.issuer} · {c.year}</p>
                  {editing && <button style={{ fontSize: 11, color: "#c2185b", background: "none", border: "none", cursor: "pointer", marginTop: 8 }} onClick={() => rmArr("certifications", c.id)}>Remove</button>}
                </div>
              ))}
            </div>
            {editing && <button className="btn-outline" style={{ borderRadius: 3, fontSize: 13, padding: "9px 20px", marginTop: 14 }} onClick={() => addArr("certifications", { id: Date.now(), name: "", issuer: "", year: "" })}>+ Add Certification</button>}
          </Sec>

          {/* Skills */}
          <Sec label="Skills">
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {p.skills.map(s => <Chip key={s} editing={editing} onRemove={() => up("skills", p.skills.filter(x => x !== s))}>{s}</Chip>)}
              {editing && (
                <input placeholder="+ Add skill" className="input-field" style={{ width: 140, fontSize: 13, padding: "5px 12px" }}
                  onKeyDown={e => { if (e.key === "Enter" && e.target.value.trim()) { up("skills", [...p.skills, e.target.value.trim()]); e.target.value = ""; } }} />
              )}
            </div>
          </Sec>

          {/* Achievements */}
          <Sec label="Achievements & Awards">
            {p.achievements.map((a, i) => (
              <div key={a.id} style={{ marginBottom: 20, paddingBottom: 20, borderBottom: i < p.achievements.length - 1 ? "1px solid rgba(180,100,130,0.1)" : "none" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                  <h3 style={{ fontSize: 15, fontWeight: 600, color: "#1a0a12" }}>{a.title}</h3>
                  <span style={{ fontSize: 12, color: "#9d6b82", flexShrink: 0 }}>{a.org} · {a.year}</span>
                </div>
                <p style={{ fontSize: 13, color: "#5a3048", marginTop: 5, fontWeight: 300, lineHeight: 1.75 }}>{a.desc}</p>
                {editing && <button style={{ fontSize: 11, color: "#c2185b", background: "none", border: "none", cursor: "pointer", marginTop: 8 }} onClick={() => rmArr("achievements", a.id)}>Remove</button>}
              </div>
            ))}
            {editing && <button className="btn-outline" style={{ borderRadius: 3, fontSize: 13, padding: "9px 20px" }} onClick={() => addArr("achievements", { id: Date.now(), title: "", org: "", year: "", desc: "" })}>+ Add Achievement</button>}
          </Sec>

          {/* Volunteering */}
          <Sec label="Volunteering">
            {p.volunteering.map(v => (
              <div key={v.id}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <h3 style={{ fontSize: 15, fontWeight: 600, color: "#1a0a12" }}>{v.role}</h3>
                  <span style={{ fontSize: 12, color: "#9d6b82" }}>{v.years}</span>
                </div>
                <p style={{ fontSize: 13, color: "#7a3d58", marginTop: 3, fontWeight: 500 }}>{v.org}</p>
                <p style={{ fontSize: 13, color: "#5a3048", marginTop: 6, fontWeight: 300, lineHeight: 1.8 }}>{v.desc}</p>
              </div>
            ))}
            {editing && <button className="btn-outline" style={{ borderRadius: 3, fontSize: 13, padding: "9px 20px", marginTop: 12 }} onClick={() => addArr("volunteering", { id: Date.now(), org: "", role: "", years: "", desc: "" })}>+ Add Volunteering</button>}
          </Sec>

          {/* Languages */}
          <Sec label="Languages">
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              {p.languages.map(l => (
                <div key={l.id} style={{ padding: "10px 16px", background: "rgba(255,255,255,0.55)", border: "1px solid rgba(194,24,91,0.1)" }}>
                  <p style={{ fontWeight: 600, fontSize: 14, color: "#1a0a12" }}>{l.name}</p>
                  <p style={{ fontSize: 12, color: "#7a3d58", marginTop: 2 }}>{l.level}</p>
                </div>
              ))}
            </div>
          </Sec>

          {/* Confidence Journey */}
          <Sec label="Confidence Journey on Renova">
            <p style={{ fontSize: 13, color: "#5a3048", fontWeight: 300, marginBottom: 16 }}>Your confidence growth since joining Renova.</p>
            <MiniLine data={dashboardMetrics.confidenceHistory} />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#9d6b82", marginTop: 10 }}>
              <span>Week 1: 20</span>
              <span style={{ color: "#c2185b", fontWeight: 600 }}>Week 7: 65 — +225%</span>
            </div>
          </Sec>
        </div>
      </div>
    </div>
  );
}
