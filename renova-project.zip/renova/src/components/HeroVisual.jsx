export default function HeroVisual() {
  return (
    <div style={{ position: "relative", width: 460, height: 520, flexShrink: 0 }}>
      <div className="morph" style={{ position: "absolute", top: "5%", left: "8%", width: 360, height: 360, background: "linear-gradient(135deg, rgba(194,24,91,0.1), rgba(233,30,140,0.05))", filter: "blur(2px)" }} />
      <div className="rotate" style={{ position: "absolute", top: "10%", left: "12%", width: 330, height: 330, border: "1px solid rgba(194,24,91,0.1)", borderRadius: "50%" }} />
      <div style={{ position: "absolute", top: "18%", left: "20%", width: 250, height: 250, border: "1px solid rgba(194,24,91,0.06)", borderRadius: "50%" }} />

      {/* Central card */}
      <div style={{ position: "absolute", top: "12%", left: "15%", width: 300, height: 380, background: "linear-gradient(175deg, rgba(255,255,255,0.92), rgba(252,228,238,0.55))", border: "1px solid rgba(194,24,91,0.1)", boxShadow: "0 24px 80px rgba(180,60,100,0.1)", overflow: "hidden" }}>
        <svg width="100%" height="100%" viewBox="0 0 300 380" fill="none">
          {[55, 95, 135, 175, 215, 255].map(x => <line key={x} x1={x} y1="0" x2={x} y2="380" stroke="rgba(194,24,91,0.04)" strokeWidth="1" />)}
          {[55, 95, 135, 175, 215, 255, 295, 335].map(y => <line key={y} x1="0" y1={y} x2="300" y2={y} stroke="rgba(194,24,91,0.04)" strokeWidth="1" />)}
          <ellipse cx="150" cy="102" rx="48" ry="58" fill="rgba(194,24,91,0.06)" stroke="rgba(194,24,91,0.14)" strokeWidth="1" />
          <path d="M68 192 Q98 158 150 154 Q202 158 232 192 L242 315 Q214 334 150 338 Q86 334 58 315 Z" fill="rgba(194,24,91,0.05)" stroke="rgba(194,24,91,0.1)" strokeWidth="1" />
          <line x1="20" y1="102" x2="84" y2="102" stroke="rgba(194,24,91,0.22)" strokeWidth="1.5" />
          <line x1="216" y1="102" x2="280" y2="102" stroke="rgba(194,24,91,0.22)" strokeWidth="1.5" />
          <line x1="20" y1="110" x2="52" y2="110" stroke="rgba(194,24,91,0.12)" strokeWidth="1" />
          <line x1="248" y1="110" x2="280" y2="110" stroke="rgba(194,24,91,0.12)" strokeWidth="1" />
        </svg>
        <div className="float" style={{ position: "absolute", bottom: 24, left: 12, background: "rgba(255,255,255,0.95)", border: "1px solid rgba(194,24,91,0.12)", padding: "10px 14px", boxShadow: "0 8px 24px rgba(194,24,91,0.1)" }}>
          <div className="serif" style={{ fontSize: 22, fontWeight: 600, color: "#c2185b" }}>94%</div>
          <div style={{ fontSize: 10, color: "#9d6b82", letterSpacing: "0.07em", marginTop: 2, textTransform: "uppercase" }}>Interview Success</div>
        </div>
        <div className="float-slow" style={{ position: "absolute", top: 20, right: 12, background: "rgba(255,255,255,0.95)", border: "1px solid rgba(194,24,91,0.12)", padding: "10px 14px", boxShadow: "0 8px 24px rgba(194,24,91,0.1)" }}>
          <div className="serif" style={{ fontSize: 22, fontWeight: 600, color: "#c2185b" }}>12,400</div>
          <div style={{ fontSize: 10, color: "#9d6b82", letterSpacing: "0.07em", marginTop: 2, textTransform: "uppercase" }}>Women Returned</div>
        </div>
      </div>
      <div style={{ position: "absolute", right: 0, top: "38%", writingMode: "vertical-rl", fontSize: 10, color: "rgba(194,24,91,0.3)", letterSpacing: "0.18em", textTransform: "uppercase", fontWeight: 600 }}>Career Re-Entry Platform</div>
    </div>
  );
}
